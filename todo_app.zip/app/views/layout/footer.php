</div>
<script src="<?= BASE_URL ?>/public/js/main.js"></script>
</body>
</html>

